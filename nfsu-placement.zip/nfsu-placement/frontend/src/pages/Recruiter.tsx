import { useCallback, useEffect, useState } from "react";
import { Category, Done, Empty, Errors, Reasons, Section, Verdict } from "../components/ui";
import { api, errorLines } from "../lib/api";
import { COURSES, inr, lpa, OFFER_TYPES, STATUS } from "../lib/format";

const NO_FILTERS = { course: "", batch: "", min_cgpa: "", max_cgpa: "", max_backlogs: "", skill: "", placement_status: "", category: "", verdict: "" };

export default function Recruiter() {
  const [drives, setDrives] = useState<any[]>([]);
  const [driveId, setDriveId] = useState<string>("talent");
  const [filters, setFilters] = useState(NO_FILTERS);
  const [rows, setRows] = useState<any[]>([]);
  const [err, setErr] = useState<string[]>([]);
  const [done, setDone] = useState("");

  useEffect(() => {
    api("/recruiter/drives").then((d) => { setDrives(d); if (d.length) setDriveId(String(d[0].id)); }).catch((e) => setErr(errorLines(e)));
  }, []);

  const load = useCallback(async () => {
    setErr([]);
    const qs = new URLSearchParams(Object.entries(filters).filter(([, v]) => v)).toString();
    try {
      if (driveId === "talent") setRows(await api(`/recruiter/talent?${qs}`));
      else setRows((await api(`/recruiter/drives/${driveId}/candidates?${qs}`)).candidates);
    } catch (e) { setErr(errorLines(e)); }
  }, [driveId, filters]);
  useEffect(() => { load(); }, [load]);

  const decide = async (appId: number, status: string) => {
    setDone("");
    try { await api(`/recruiter/applications/${appId}`, { body: { status } }); setDone(`Candidate marked ${status}.`); load(); }
    catch (e) { setErr(errorLines(e)); }
  };
  const set = (k: keyof typeof NO_FILTERS) => (e: { target: { value: string } }) => setFilters({ ...filters, [k]: e.target.value });
  const drive = drives.find((d) => String(d.id) === driveId);
  const talent = driveId === "talent";

  return (
    <div className="stack">
      <header className="page-head">
        <h1>Candidates</h1>
        <p className="muted">Academic statistics and policy notes are here to help you decide. Contact details appear once you shortlist a candidate.</p>
      </header>

      <div className="row wrap">
        <label className="inline">Show
          <select value={driveId} onChange={(e) => setDriveId(e.target.value)}>
            {drives.map((d) => <option key={d.id} value={d.id}>Applicants: {d.title} ({d.applicant_count})</option>)}
            <option value="talent">Talent pool (all consenting students)</option>
          </select>
        </label>
        {drive && <span className="muted">{OFFER_TYPES[drive.offer_type]} · {drive.ctc_lpa ? lpa(drive.ctc_lpa) : `${inr(drive.stipend_amount)} / month`} · category <Category value={drive.category} /></span>}
      </div>

      <form className="filters" onSubmit={(e) => e.preventDefault()} aria-label="Filter candidates">
        <label>Programme<select value={filters.course} onChange={set("course")}><option value="">Any</option>{Object.entries(COURSES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
        <label>Batch<input value={filters.batch} onChange={set("batch")} placeholder="2025-27" maxLength={7} /></label>
        <label>CGPA from<input type="number" step="0.1" min="0" max="10" value={filters.min_cgpa} onChange={set("min_cgpa")} /></label>
        <label>CGPA to<input type="number" step="0.1" min="0" max="10" value={filters.max_cgpa} onChange={set("max_cgpa")} /></label>
        <label>Max backlogs<input type="number" min="0" value={filters.max_backlogs} onChange={set("max_backlogs")} /></label>
        <label>Skill<input value={filters.skill} onChange={set("skill")} maxLength={40} /></label>
        <label>Placement status<select value={filters.placement_status} onChange={set("placement_status")}><option value="">Any</option>{Object.entries(STATUS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
        <label>Current category<select value={filters.category} onChange={set("category")}><option value="">Any</option><option value="none">No FTE offer</option>{["A+", "A", "B", "C"].map((c) => <option key={c}>{c}</option>)}</select></label>
        {!talent && <label>Policy note<select value={filters.verdict} onChange={set("verdict")}><option value="">Any</option><option value="ALLOW">Clear</option><option value="FLAG">Review</option><option value="BLOCK">Blocked</option></select></label>}
        <button type="button" className="btn-quiet" onClick={() => setFilters(NO_FILTERS)}>Clear filters</button>
      </form>

      <Errors lines={err} />
      <Done text={done} />
      <Section title={`${rows.length} ${talent ? "students" : "candidates"}`}>
        {rows.length === 0 ? <Empty>No one matches these filters. Widen the CGPA range or clear a filter.</Empty> : (
          <div className="table-wrap"><table className="candidates">
            <thead><tr>
              <th>Candidate</th><th>Programme</th><th className="num">CGPA</th><th className="num">Backlogs</th><th className="num">10th / 12th</th>
              <th>Skills</th><th>Status</th><th>Category</th>{!talent && <><th>Policy</th><th>Contact</th><th>Decision</th></>}
            </tr></thead>
            <tbody>{rows.map((r) => (
              <tr key={r.placement_id}>
                <td><strong>{r.name}</strong><br /><span className="muted small">{r.placement_id}</span>
                  {r.has_resume && <><br /><a href={`/api/resumes/${encodeURIComponent(r.placement_id)}`} target="_blank" rel="noopener noreferrer">Resume</a></>}</td>
                <td>{COURSES[r.course]}<br /><span className="muted small">{r.batch}</span></td>
                <td className="num">{r.cgpa}</td>
                <td className="num">{r.backlogs}</td>
                <td className="num">{r.tenth_percent ?? "—"} / {r.twelfth_percent ?? "—"}</td>
                <td className="small">{r.skills.join(", ")}</td>
                <td>{STATUS[r.placement_status]}</td>
                <td><Category value={r.current_category} /></td>
                {!talent && <>
                  <td><Verdict decision={r.verdict} /><Reasons reasons={r.reasons} /></td>
                  <td className="small">{r.contact_masked ? <span className="muted">Shortlist to see</span> : <>{r.email}<br />{r.mobile}</>}</td>
                  <td>
                    <p className="small">{r.application_status}</p>
                    <div className="row tight">
                      {r.application_status === "applied" && <button className="btn" onClick={() => decide(r.application_id, "shortlisted")}>Shortlist</button>}
                      {r.application_status === "shortlisted" && <button className="btn" onClick={() => decide(r.application_id, "selected")}>Select</button>}
                      {["applied", "shortlisted"].includes(r.application_status) && <button className="btn-quiet" onClick={() => decide(r.application_id, "rejected")}>Not selected</button>}
                    </div>
                  </td>
                </>}
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </Section>
      {drives.length === 0 && <Empty>Your organisation has no drives yet. The Placement Cell creates drives once dates are agreed.</Empty>}
    </div>
  );
}
