import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import BulletinList, { Post } from "../components/BulletinList";
import { Empty, Section } from "../components/ui";
import { api } from "../lib/api";
import { inr, lpa } from "../lib/format";

interface PublicStats {
  session: string;
  min_cell_size: number;
  registered_students: number | null;
  students_placed: number | null;
  offers_made: number | null;
  recruiters: number;
  fte_ctc_lpa: { highest: number; average: number; median: number } | null;
  internship_stipend_monthly_inr: { average: number; median: number } | null;
  by_course: { course: string; registered: number | null; placed: number | null; placement_rate: number | null }[];
  past_recruiters: string[];
  top_packages: { student: string; course: string; company: string; ctc_lpa: number }[];
}

const few = (n: number | null | undefined, k: number) => (n === null || n === undefined ? `<${k}` : n.toLocaleString("en-IN"));

export default function Home() {
  const [s, setS] = useState<PublicStats | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  useEffect(() => {
    api<PublicStats>("/public/stats").then(setS).catch(() => setS(null));
    api<Post[]>("/public/bulletin").then(setPosts).catch(() => setPosts([]));
  }, []);
  const k = s?.min_cell_size ?? 5;

  return (
    <div className="home">
      <section className="hero">
        <h1>Placement session {s?.session ?? "2026–27"}</h1>
        <p className="lede">
          Outcomes for the five computing programmes at NFSU, published from approved figures. Groups smaller than {k} students are
          not shown, so no individual can be identified.
        </p>
        <dl className="ledger">
          <div><dt>Students placed</dt><dd>{few(s?.students_placed, k)}</dd></div>
          <div><dt>Offers made</dt><dd>{few(s?.offers_made, k)}</dd></div>
          <div><dt>Recruiting organisations</dt><dd>{s?.recruiters ?? "—"}</dd></div>
          <div><dt>Median FTE package</dt><dd>{s?.fte_ctc_lpa ? lpa(s.fte_ctc_lpa.median) : "—"}</dd></div>
        </dl>
        <p className="fine">Students placed counts each person once; offers made counts every offer, so the two differ.</p>
      </section>

      <div className="home-grid">
        <Section title="By programme">
          <div className="table-wrap">
            <table>
              <thead><tr><th>Programme</th><th className="num">Registered</th><th className="num">Placed</th><th className="num">Rate</th></tr></thead>
              <tbody>
                {s?.by_course.map((c) => (
                  <tr key={c.course}>
                    <td>{c.course}</td>
                    <td className="num">{few(c.registered, k)}</td>
                    <td className="num">{few(c.placed, k)}</td>
                    <td className="num">{c.placement_rate === null ? "—" : `${c.placement_rate}%`}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="pair">
            <div>
              <h3>FTE packages (annual CTC)</h3>
              {s?.fte_ctc_lpa ? (
                <p>Highest {lpa(s.fte_ctc_lpa.highest)}, average {lpa(s.fte_ctc_lpa.average)}, median {lpa(s.fte_ctc_lpa.median)}</p>
              ) : <p className="muted">Not enough accepted offers yet to publish.</p>}
            </div>
            <div>
              <h3>Internship stipends (monthly)</h3>
              {s?.internship_stipend_monthly_inr ? (
                <p>Average {inr(s.internship_stipend_monthly_inr.average)}, median {inr(s.internship_stipend_monthly_inr.median)}</p>
              ) : <p className="muted">Not enough internships yet to publish.</p>}
            </div>
          </div>
        </Section>

        <Section title="Placement bulletin" aside={<Link to="/login">Sign in for talk links</Link>}>
          <BulletinList posts={posts} />
        </Section>
      </div>

      <div className="home-grid">
        <Section title="Organisations that recruited">
          {s?.past_recruiters.length ? <p className="recruiters">{s.past_recruiters.join(", ")}</p> : <Empty>The first drives of the session are under way.</Empty>}
        </Section>
        <Section title="Top packages">
          <p className="muted small">Only students who chose to be listed appear here.</p>
          {s?.top_packages.length ? (
            <ul className="plain">
              {s.top_packages.map((t, i) => <li key={i}><strong>{lpa(t.ctc_lpa)}</strong> {t.student}, {t.course}, at {t.company}</li>)}
            </ul>
          ) : <Empty>No one has opted in yet.</Empty>}
        </Section>
      </div>

      <section className="contact">
        <div>
          <h2>Recruit at NFSU</h2>
          <p>Tell the Placement Cell about your roles. Once your organisation is verified you receive a Recruiter ID to sign in.</p>
          <Link className="btn" to="/recruit">Register your interest</Link>
        </div>
        <div>
          <h2>Contact</h2>
          <p>Placement Cell, National Forensic Sciences University, Sector 9, Gandhinagar, Gujarat 382007</p>
          <p><a href="mailto:placement-cell@nfsu.local">placement-cell@nfsu.local</a></p>
        </div>
        <div>
          <h2>Team</h2>
          <p>Built for the NFSU coders' hackathon by the team. Add your names in <code>src/pages/Home.tsx</code>.</p>
        </div>
      </section>
    </div>
  );
}
