import { FormEvent, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Errors } from "../components/ui";
import { api, ApiError, errorLines } from "../lib/api";
import { homeFor, Me, useAuth } from "../lib/auth";

export default function Login() {
  const { setMe } = useAuth();
  const nav = useNavigate();
  const [username, setU] = useState("");
  const [password, setP] = useState("");
  const [otp, setOtp] = useState("");
  const [needOtp, setNeedOtp] = useState(false);
  const [err, setErr] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr([]);
    try {
      const me = await api<Me>("/auth/login", { body: { username, password, otp } });
      setMe(me);
      nav(homeFor(me.role));
    } catch (ex) {
      if (ex instanceof ApiError && ex.data.otp_required) setNeedOtp(true);
      setErr(errorLines(ex));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="narrow">
      <h1>Sign in</h1>
      <p className="muted">Students use their Placement ID. Recruiters use the Recruiter ID from their activation email.</p>
      <form onSubmit={submit} className="form">
        <label>
          Placement ID, Recruiter ID or staff ID
          <input value={username} onChange={(e) => setU(e.target.value)} autoComplete="username" required maxLength={150} />
        </label>
        <label>
          Password
          <input type="password" value={password} onChange={(e) => setP(e.target.value)} autoComplete="current-password" required />
        </label>
        {needOtp && (
          <label>
            Code from your authenticator app
            <input value={otp} onChange={(e) => setOtp(e.target.value)} inputMode="numeric" autoComplete="one-time-code" maxLength={6} />
          </label>
        )}
        <Errors lines={err} />
        <button className="btn" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button>
      </form>
    </div>
  );
}
