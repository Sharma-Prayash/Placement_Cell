import { useCallback, useEffect, useState } from "react";
import { Category, Done, Empty, Errors, Reasons, Section, Verdict } from "../components/ui";
import { api, errorLines } from "../lib/api";
import { COURSES, inr, lpa, OFFER_TYPES, STATUS, when } from "../lib/format";

export default function Student() {
  const [me, setMe] = useState<any>(null);
  const [drives, setDrives] = useState<any[]>([]);
  const [data, setData] = useState<{ offers: any[]; applications: any[] }>({ offers: [], applications: [] });
  const [err, setErr] = useState<string[]>([]);
  const [done, setDone] = useState("");

  const load = useCallback(async () => {
    try {
      const [m, d, o] = await Promise.all([api("/student/me"), api("/student/drives"), api("/student/offers")]);
      setMe(m); setDrives(d); setData(o);
    } catch (e) { setErr(errorLines(e)); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const act = async (fn: () => Promise<unknown>, msg: string) => {
    setErr([]); setDone("");
    try { await fn(); setDone(msg); await load(); } catch (e) { setErr(errorLines(e)); }
  };
  const upload = (file?: File) => {
    if (!file) return;
    const form = new FormData();
    form.append("resume", file);
    act(() => api("/student/resume", { form }), "Resume uploaded.");
  };

  if (!me) return <Errors lines={err} />;
  return (
    <div className="stack">
      <header className="page-head">
        <h1>{me.name}</h1>
        <p className="muted">{me.placement_id} · {COURSES[me.course]} · batch {me.batch}</p>
      </header>
      <Errors lines={err} />
      <Done text={done} />

      <dl className="facts">
        <div><dt>Placement status</dt><dd>{STATUS[me.placement_status]}</dd></div>
        <div><dt>Current category</dt><dd><Category value={me.current_category} /></dd></div>
        <div><dt>Registration</dt><dd>{me.registration_status.replace("_", " ")}</dd></div>
        <div><dt>Eligibility</dt><dd>{me.eligibility_status}</dd></div>
        <div><dt>CGPA</dt><dd>{me.cgpa}</dd></div>
      </dl>
      <p className="fine">Your status, package and eligibility are maintained by the Placement Cell. If something is wrong, contact them; you cannot change these fields yourself.</p>

      <Section title="Offers">
        {data.offers.length === 0 ? <Empty>No offers yet. Apply to open drives below.</Empty> : (
          <div className="table-wrap"><table>
            <thead><tr><th>Company</th><th>Type</th><th className="num">Package</th><th>Status</th><th>Respond by</th><th /></tr></thead>
            <tbody>{data.offers.map((o) => (
              <tr key={o.id}>
                <td>{o.company_name}</td>
                <td>{OFFER_TYPES[o.offer_type]}</td>
                <td className="num">{o.offer_type === "I" ? `${inr(o.stipend_amount)} / ${o.stipend_period || "month"}` : lpa(o.ctc_lpa)}</td>
                <td>{o.acceptance}{o.acceptance === "accepted" && `, joining ${o.joining_status.replace("_", " ")}`}</td>
                <td>{o.acceptance === "pending" ? when(o.acceptance_deadline) : "—"}</td>
                <td>{o.acceptance === "pending" && (
                  <div className="row">
                    <button className="btn" onClick={() => act(() => api(`/student/offers/${o.id}/respond`, { body: { decision: "accept" } }), "Offer accepted.")}>Accept</button>
                    <button className="btn-quiet" onClick={() => act(() => api(`/student/offers/${o.id}/respond`, { body: { decision: "decline" } }), "Offer declined.")}>Decline</button>
                  </div>
                )}</td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </Section>

      <Section title="Open drives for your programme">
        {drives.length === 0 ? <Empty>No drives are open for {COURSES[me.course]} right now.</Empty> : (
          <ul className="cards">
            {drives.map((d) => (
              <li key={d.id} className="drive">
                <div className="drive-head">
                  <div>
                    <h3>{d.company_name}: {d.title}</h3>
                    <p className="muted">{OFFER_TYPES[d.offer_type]} · {d.ctc_lpa ? lpa(d.ctc_lpa) : `${inr(d.stipend_amount)} / month`} · closes {when(d.application_deadline)}</p>
                  </div>
                  <Verdict decision={d.verdict.decision} />
                </div>
                <Reasons reasons={d.verdict.reasons} />
                {d.application_status ? <p className="ok-text">Applied: {d.application_status}</p> : d.verdict.decision !== "BLOCK" && (
                  <button className="btn" onClick={() => act(() => api(`/student/drives/${d.id}/apply`, { method: "POST" }), `Applied to ${d.company_name}.`)}>Apply</button>
                )}
              </li>
            ))}
          </ul>
        )}
      </Section>

      <Section title="Profile and consent">
        <div className="form">
          <label>Skills (comma-separated)
            <input defaultValue={me.skills} maxLength={300} onBlur={(e) => e.target.value !== me.skills && act(() => api("/student/me", { method: "PATCH", body: { skills: e.target.value } }), "Skills saved.")} />
          </label>
          <label className="check"><input type="checkbox" checked={me.consent_share_with_recruiters}
            onChange={(e) => act(() => api("/student/me", { method: "PATCH", body: { consent_share_with_recruiters: e.target.checked } }), "Preference saved.")} />
            Let verified recruiters see my academic profile and resume</label>
          <label className="check"><input type="checkbox" checked={me.consent_public_listing}
            onChange={(e) => act(() => api("/student/me", { method: "PATCH", body: { consent_public_listing: e.target.checked } }), "Preference saved.")} />
            List my first name and package on the public top-packages list</label>
          <label>Resume (PDF, up to 2 MB){me.has_resume && " — uploaded"}
            <input type="file" accept="application/pdf" onChange={(e) => upload(e.target.files?.[0])} />
          </label>
        </div>
      </Section>
    </div>
  );
}
