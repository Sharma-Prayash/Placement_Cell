import { FormEvent, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { Done, Errors } from "../components/ui";
import { api, errorLines } from "../lib/api";

export default function Activate() {
  const [params] = useSearchParams();
  const [password, setP] = useState("");
  const [confirm, setC] = useState("");
  const [err, setErr] = useState<string[]>([]);
  const [done, setDone] = useState("");

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (password !== confirm) return setErr(["The two passwords do not match."]);
    setErr([]);
    try {
      const r = await api<{ username: string }>("/auth/activate", { body: { uid: params.get("uid"), token: params.get("token"), password } });
      setDone(`Password set for ${r.username}. You can sign in now.`);
    } catch (ex) {
      setErr(errorLines(ex));
    }
  };
  return (
    <div className="narrow">
      <h1>Set your password</h1>
      <p className="muted">Use at least 12 characters. This link works once and expires after 24 hours.</p>
      {done ? (
        <>
          <Done text={done} />
          <Link className="btn" to="/login">Sign in</Link>
        </>
      ) : (
        <form className="form" onSubmit={submit}>
          <label>New password<input type="password" minLength={12} value={password} onChange={(e) => setP(e.target.value)} autoComplete="new-password" required /></label>
          <label>Repeat the password<input type="password" minLength={12} value={confirm} onChange={(e) => setC(e.target.value)} autoComplete="new-password" required /></label>
          <Errors lines={err} />
          <button className="btn">Set password</button>
        </form>
      )}
    </div>
  );
}
