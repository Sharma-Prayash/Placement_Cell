import { ReactNode } from "react";

type Decision = "ALLOW" | "FLAG" | "BLOCK";
const DECISION_TEXT: Record<Decision, string> = { ALLOW: "Clear", FLAG: "Review", BLOCK: "Blocked" };

/** Evidence-tag style verdict marker: the one distinctive element of the interface. */
export function Verdict({ decision }: { decision: Decision }) {
  return <span className={`tag tag-${decision.toLowerCase()}`}>{DECISION_TEXT[decision] ?? decision}</span>;
}

export function Category({ value }: { value?: string | null }) {
  if (!value) return <span className="muted">—</span>;
  return <span className="cat">{value}</span>;
}

export function Reasons({ reasons }: { reasons: { severity: string; message: string }[] }) {
  const shown = reasons.filter((r) => r.severity !== "info");
  if (!shown.length) return null;
  return (
    <ul className="reasons">
      {shown.map((r, i) => (
        <li key={i} className={`reason-${r.severity}`}>
          {r.message}
        </li>
      ))}
    </ul>
  );
}

export function Errors({ lines }: { lines: string[] }) {
  if (!lines.length) return null;
  return (
    <div className="notice notice-error" role="alert">
      {lines.map((l, i) => (
        <p key={i}>{l}</p>
      ))}
    </div>
  );
}

export function Done({ text }: { text: string }) {
  return text ? (
    <div className="notice notice-ok" role="status">
      {text}
    </div>
  ) : null;
}

export function Section({ title, aside, children }: { title: string; aside?: ReactNode; children: ReactNode }) {
  return (
    <section className="section">
      <header className="section-head">
        <h2>{title}</h2>
        {aside}
      </header>
      {children}
    </section>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <p className="empty">{children}</p>;
}
