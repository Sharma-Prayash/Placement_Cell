import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { homeFor, isStaff, useAuth } from "../lib/auth";

export default function Layout() {
  const { me, signOut } = useAuth();
  const nav = useNavigate();
  return (
    <div className="shell">
      <a href="#main" className="skip">Skip to content</a>
      <header className="topbar">
        <NavLink to="/" className="brand" aria-label="NFSU Placement Cell home">
          <span className="brand-mark" aria-hidden="true">NFSU</span>
          <span className="brand-name">Placement Cell</span>
        </NavLink>
        <nav className="nav" aria-label="Main">
          <NavLink to="/" end>Overview</NavLink>
          {me && <NavLink to="/bulletin">Bulletin</NavLink>}
          {me?.role === "student" && <NavLink to="/student">My placement</NavLink>}
          {me?.role === "recruiter" && <NavLink to="/recruiter">Candidates</NavLink>}
          {isStaff(me?.role) && <NavLink to="/staff">Console</NavLink>}
          {!me && <NavLink to="/recruit">Recruit at NFSU</NavLink>}
        </nav>
        <div className="who">
          {me ? (
            <>
              <span className="who-name">
                {me.name}
                <small>{me.company ?? me.role}</small>
              </span>
              <button className="btn-quiet" onClick={async () => { await signOut(); nav("/"); }}>Sign out</button>
            </>
          ) : (
            <NavLink className="btn" to="/login">Sign in</NavLink>
          )}
        </div>
      </header>
      <main id="main" className="main">
        <Outlet />
      </main>
      <footer className="foot">
        <span>National Forensic Sciences University, Gandhinagar · Placement Cell</span>
        {me && <NavLink to={homeFor(me.role)}>Back to my dashboard</NavLink>}
      </footer>
    </div>
  );
}
